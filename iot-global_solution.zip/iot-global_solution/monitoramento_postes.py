import cv2
import mediapipe as mp
import numpy as np
from typing import Tuple, Dict
from datetime import datetime, time
import requests
import pytz
import smtplib
import json
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


def obter_horarios_sol_sp() -> Tuple[time, time]:
    latitude = -23.55052
    longitude = -46.633308
    url = f"https://api.sunrise-sunset.org/json?lat={latitude}&lng={longitude}&formatted=0"

    try:
        response = requests.get(url)
        data = response.json()
        sunrise_utc = data['results']['sunrise']
        sunset_utc = data['results']['sunset']

        sunrise_dt_utc = datetime.fromisoformat(sunrise_utc)
        sunset_dt_utc = datetime.fromisoformat(sunset_utc)

        tz_sp = pytz.timezone("America/Sao_Paulo")
        sunrise_local = sunrise_dt_utc.astimezone(tz_sp)
        sunset_local = sunset_dt_utc.astimezone(tz_sp)

        return sunrise_local.time(), sunset_local.time()
    except Exception as e:
        print(f"Erro ao obter horários do sol: {e}")
        # Valores padrão caso falhe
        return time(6, 0), time(18, 0)


class PosteMonitor:
    def __init__(
        self,
        video_path: str,
        postes_roi: Dict[str, Tuple[int, int, int, int]],
        frames_calibracao: int = 30,
        frames_apagado_necessarios: int = 5,
        calib_percent: float = 0.80,
        min_text_margin: int = 10,
        inicio_monitoramento: time = time(18, 30),
        fim_monitoramento: time = time(5, 30),
        email_remetente: str = "seu_email@gmail.com",
        email_senha_app: str = "sua_senha_de_aplicativo",
        email_destino: str = "destino@gmail.com",
        arquivo_log: str = "apagao_log.json",
    ):
        self.video_path = video_path
        self.postes_roi = postes_roi
        self.frames_calibracao = frames_calibracao
        self.frames_apagado_necessarios = frames_apagado_necessarios
        self.calib_percent = calib_percent
        self.min_text_margin = min_text_margin
        self.inicio_monitoramento = inicio_monitoramento
        self.fim_monitoramento = fim_monitoramento

        self.email_remetente = email_remetente
        self.email_senha_app = email_senha_app
        self.email_destino = email_destino

        self.arquivo_log = arquivo_log

        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5)

        self.estado_postes = {
            nome: {"luz_acesa": True, "contador_apagado": 0} for nome in postes_roi.keys()
        }

        self.limiar_postes = {nome: 0.0 for nome in postes_roi.keys()}

        if not os.path.isfile(self.arquivo_log):
            with open(self.arquivo_log, 'w', encoding='utf-8') as f:
                json.dump([], f, indent=2)

    @staticmethod
    def brilho_medio_roi(frame: np.ndarray, roi: Tuple[int, int, int, int]) -> float:
        x, y, w, h = roi
        roi_img = frame[y : y + h, x : x + w]
        gray = cv2.cvtColor(roi_img, cv2.COLOR_BGR2GRAY)
        return float(np.mean(gray))

    def calibrar_brilho(self) -> None:
        cap = cv2.VideoCapture(self.video_path)
        print("Iniciando calibração do brilho dos postes...")
        for nome, roi in self.postes_roi.items():
            br_list = []
            frames_lidos = 0
            while frames_lidos < self.frames_calibracao:
                ret, frame = cap.read()
                if not ret:
                    break
                brilho = self.brilho_medio_roi(frame, roi)
                br_list.append(brilho)
                frames_lidos += 1
            media = np.mean(br_list) if br_list else 0.0
            self.limiar_postes[nome] = media * self.calib_percent
            print(f"Limiar calibrado - {nome}: {self.limiar_postes[nome]:.2f}")
        cap.release()

    def ajustar_posicao_texto(
        self,
        frame: np.ndarray,
        x: int,
        y: int,
        texto: str,
        fonte,
        escala: float,
        espessura: int,
    ) -> Tuple[int, int]:
        (text_largura, text_altura), _ = cv2.getTextSize(texto, fonte, escala, espessura)
        largura_frame = frame.shape[1]
        altura_frame = frame.shape[0]

        if x + text_largura > largura_frame:
            x = largura_frame - text_largura - self.min_text_margin

        if y - text_altura < 0:
            y = text_altura + self.min_text_margin
        elif y > altura_frame:
            y = altura_frame - self.min_text_margin

        return x, y

    def esta_no_horario_monitoramento(self) -> bool:
        agora = datetime.now().time()
        if self.inicio_monitoramento < self.fim_monitoramento:
            return self.inicio_monitoramento <= agora <= self.fim_monitoramento
        else:
            return agora >= self.inicio_monitoramento or agora <= self.fim_monitoramento

    def pegar_localizacao(self) -> Tuple[str, str, str, str]:
        try:
            response = requests.get("https://ipinfo.io/json")
            data = response.json()
            loc = data.get("loc", "Desconhecida")
            cidade = data.get("city", "Desconhecida")
            estado = data.get("region", "Desconhecida")
            pais = data.get("country", "Desconhecido")
            return loc, cidade, estado, pais
        except Exception as e:
            print(f"Erro ao obter localização: {e}")
            return "Indisponível", "Indisponível", "Indisponível", "Indisponível"

    def salvar_log_json(self, nome_poste: str, brilho: int, evento: str) -> None:
        horario = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        loc, cidade, estado, pais = self.pegar_localizacao()

        evento_obj = {
            "horario": horario,
            "evento": evento,
            "poste": nome_poste,
            "brilho": brilho,
            "localizacao": {
                "latlong": loc,
                "cidade": cidade,
                "estado": estado,
                "pais": pais,
            },
        }

        try:
            with open(self.arquivo_log, "r+", encoding="utf-8") as f:
                dados = json.load(f)
                dados.append(evento_obj)
                f.seek(0)
                json.dump(dados, f, indent=2)
                f.truncate()
        except Exception as e:
            print(f"Erro ao salvar log JSON: {e}")

    def enviar_alerta_email(self, nome_poste: str, brilho: int, evento: str = "queda") -> None:
        horario = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        loc, cidade, estado, pais = self.pegar_localizacao()

        if evento == "queda":
            subject = f"Alerta de Apagão: {nome_poste} - {horario}"
            body = (
                f"Detectado apagão no poste '{nome_poste}'.\n"
                f"Horário da detecção: {horario}\n"
                f"Brilho medido: {brilho}\n"
                f"Localização aproximada (lat,long): {loc}\n"
                f"Cidade: {cidade}\n"
                f"Estado: {estado}\n"
                f"País: {pais}\n\n"
                f"Favor verificar o local imediatamente."
            )
        elif evento == "retorno":
            subject = f"Alerta de Retorno de Luz: {nome_poste} - {horario}"
            body = (
                f"A luz voltou no poste '{nome_poste}'.\n"
                f"Horário da detecção: {horario}\n"
                f"Brilho medido: {brilho}\n"
                f"Localização aproximada (lat,long): {loc}\n"
                f"Cidade: {cidade}\n"
                f"Estado: {estado}\n"
                f"País: {pais}\n\n"
                f"Normalização do sistema."
            )
        else:
            return

        msg = MIMEMultipart()
        msg['From'] = self.email_remetente
        msg['To'] = self.email_destino
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))

        try:
            server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
            server.login(self.email_remetente, self.email_senha_app)
            server.sendmail(self.email_remetente, self.email_destino, msg.as_string())
            server.quit()
            print(f"Alerta '{evento}' enviado para {self.email_destino}")
            self.salvar_log_json(nome_poste, brilho, evento)
        except Exception as e:
            print(f"Erro ao enviar e-mail: {e}")

    def checar_poste(self, frame: np.ndarray, nome: str, roi: Tuple[int, int, int, int]) -> None:
        brilho = self.brilho_medio_roi(frame, roi)
        estado = self.estado_postes[nome]
        limiar = self.limiar_postes[nome]

        if self.esta_no_horario_monitoramento():
            if brilho < limiar:
                estado["contador_apagado"] += 1
            else:
                estado["contador_apagado"] = 0

            if estado["luz_acesa"] and estado["contador_apagado"] >= self.frames_apagado_necessarios:
                print(f"Queda de energia detectada no {nome}!")
                estado["luz_acesa"] = False
                self.enviar_alerta_email(nome, int(brilho), evento="queda")

            if not estado["luz_acesa"] and brilho > limiar:
                print(f"Luz voltou no {nome}!")
                estado["luz_acesa"] = True
                estado["contador_apagado"] = 0
                self.enviar_alerta_email(nome, int(brilho), evento="retorno")
        else:
            estado["contador_apagado"] = 0
            if not estado["luz_acesa"]:
                print(f"Luz desligada de dia no {nome} (não é queda).")
            estado["luz_acesa"] = True

        x, y, w, h = roi
        cor = (0, 255, 0) if estado["luz_acesa"] else (0, 0, 255)
        cv2.rectangle(frame, (x, y), (x + w, y + h), cor, 2)

        texto = f"{nome} Brilho: {int(brilho)}"
        x_texto, y_texto = self.ajustar_posicao_texto(
            frame, x, y - 10, texto, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2
        )
        cv2.putText(frame, texto, (x_texto, y_texto), cv2.FONT_HERSHEY_SIMPLEX, 0.6, cor, 2)

    def run(self) -> None:
        self.calibrar_brilho()
        cap = cv2.VideoCapture(self.video_path)

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = self.pose.process(frame_rgb)

            if results.pose_landmarks:
                mp.solutions.drawing_utils.draw_landmarks(
                    frame, results.pose_landmarks, self.mp_pose.POSE_CONNECTIONS
                )

            for nome, roi in self.postes_roi.items():
                self.checar_poste(frame, nome, roi)

            cv2.imshow("Monitoramento 2 Postes e Humano", frame)
            if cv2.waitKey(30) & 0xFF == 27:
                break

        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    postes = {
        "Poste 1": (61, 275, 55, 50),
        "Poste 2": (359, 398, 37, 30),
    }
    nascer_sol, por_sol = obter_horarios_sol_sp()
    print(f"Pôr do sol: {por_sol}, Nascer do sol: {nascer_sol}")

    monitor = PosteMonitor(
        video_path="cenario_real.mp4", 
        postes_roi=postes,
        inicio_monitoramento=por_sol, #Caso rode antes do por do sol: time(5, 31)
        fim_monitoramento=nascer_sol,  #Caso rode depois do nascer do sol: time(5, 30)
        email_remetente="guidalposolo@gmail.com", 
        email_senha_app="ekkg abcb jmyj khvg", 
        email_destino="posolomatheus@gmail.com", #Você pode colocar o seu e-mail
    )
    monitor.run()